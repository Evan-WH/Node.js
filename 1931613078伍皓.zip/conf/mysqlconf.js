module.exports={
    mysql:{
        host:'172.29.65.54',
        user:'root',
        password:'12345',
        database:'studentmanager',
        connLimit:10 //最大连接数10
    }
}